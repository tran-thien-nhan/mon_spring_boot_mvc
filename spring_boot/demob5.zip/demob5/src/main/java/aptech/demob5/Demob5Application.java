package aptech.demob5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demob5Application {

	public static void main(String[] args) {
		SpringApplication.run(Demob5Application.class, args);
	}

}
