package asm.asm1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Asm1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
