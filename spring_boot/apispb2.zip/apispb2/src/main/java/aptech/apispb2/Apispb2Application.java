package aptech.apispb2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Apispb2Application {

	public static void main(String[] args) {
		SpringApplication.run(Apispb2Application.class, args);
	}

}
